## Hi, I'm Aliss 👋

**Geophysicist · AI & Deep Learning Researcher · Ceramic Additive Manufacturing**

I am a PhD candidate at **Universidad Carlos III de Madrid** and the **Institute of Ceramics and Glass (ICV-CSIC)**, where I apply machine learning to the design of ceramic inks for **Direct Ink Writing (robocasting)**. I combine materials engineering, data science and automation to build intelligent tools for scientific research.

### 🔬 What I work on
- **Graph neural networks** linking ink composition, rheology and printability
- **CERML** — extracting DIW printing parameters from scientific literature with NLP and LLMs
- Scientific data extraction, predictive modelling and AI-driven research software
- Background in geophysical modelling, potential fields and numerical simulation

### 🛠️ Tools
Python · PyTorch · scikit-learn · LLMs & RAG · FastAPI · Docker · R · COMSOL · Petrel · Oasis Montaj

### 🌐 Find me
[Website](https://alissgeomath2.github.io) · [LinkedIn](https://www.linkedin.com/in/alissgeomath) · [ORCID](https://orcid.org/0009-0008-3932-5140) · [Email](mailto:alissbejerano@gmail.com)
